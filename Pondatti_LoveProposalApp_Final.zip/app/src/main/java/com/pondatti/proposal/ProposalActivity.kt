package com.pondatti.proposal

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProposalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proposal)

        val yesButton = findViewById<Button>(R.id.yesButton)
        val noButton = findViewById<Button>(R.id.noButton)

        yesButton.setOnClickListener {
            val intent = Intent(this, AcceptedActivity::class.java)
            startActivity(intent)
        }

        noButton.setOnClickListener {
            Toast.makeText(this, "Take your time! 💬", Toast.LENGTH_SHORT).show()
        }
    }
}